package com.raylan.vrxotmz;

interface IShellService {
    void destroy() = 16777114;
    String runCommand(String command) = 1;
}
