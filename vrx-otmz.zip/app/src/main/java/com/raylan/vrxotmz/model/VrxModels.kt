package com.raylan.vrxotmz.model

import androidx.compose.ui.graphics.ImageBitmap

enum class FpsMode(
  val id: String,
  val title: String,
  val shortLabel: String,
  val subtitle: String,
  val targetFps: Int,
  val targetRefreshHz: Float?,
) {
  FPS_60(
    id = "fps_60",
    title = "60 FPS",
    shortLabel = "60",
    subtitle = "Modo Padrão Estável",
    targetFps = 60,
    targetRefreshHz = 60.0f,
  ),
  FPS_100(
    id = "fps_100",
    title = "100 FPS CRAVADO",
    shortLabel = "100",
    subtitle = "Trava min/peak em 100Hz e força FPS 100",
    targetFps = 100,
    targetRefreshHz = 100.0f,
  ),
  FPS_120(
    id = "fps_120",
    title = "120 FPS CRAVADO",
    shortLabel = "120",
    subtitle = "Trava min/peak em 120Hz e força FPS 120",
    targetFps = 120,
    targetRefreshHz = 120.0f,
  ),
  FPS_300(
    id = "fps_300",
    title = "300 FPS EXTREMO",
    shortLabel = "300",
    subtitle = "Destrava limite máximo do motor gráfico e Hz máximo",
    targetFps = 300,
    targetRefreshHz = null,
  );

  companion object {
    fun fromId(id: String?): FpsMode = entries.firstOrNull { it.id == id } ?: FPS_120
  }
}

enum class TweakCategory(val label: String) {
  GPU("GPU"),
  CPU("CPU / KERNEL"),
  MEMORIA("MEMÓRIA"),
  SISTEMA("SISTEMA"),
  REDE("REDE & TOQUE"),
}

data class OptimizationTweak(
  val id: String,
  val index: Int,
  val title: String,
  val description: String,
  val category: TweakCategory,
  val isEnabled: Boolean = false,
)

data class InstalledGame(
  val appName: String,
  val packageName: String,
  val isFeatured: Boolean,
  val isGameCategory: Boolean,
  val isInstalled: Boolean,
  val iconBitmap: ImageBitmap? = null,
)

sealed interface ShizukuStatus {
  data object NotRunning : ShizukuStatus

  data object PermissionRequired : ShizukuStatus

  data class Authorized(val uid: Int, val version: Int) : ShizukuStatus
}

sealed interface BoostPhase {
  data class Prepared(val preparedCount: Int) : BoostPhase

  data class Applying(
    val currentStep: Int,
    val totalSteps: Int,
    val currentLabel: String,
  ) : BoostPhase

  data class Active(
    val gameName: String,
    val fpsMode: FpsMode,
    val appliedCount: Int,
    val maxHardwareHz: Float,
    val summaryLog: List<String>,
  ) : BoostPhase

  data class Error(val message: String) : BoostPhase
}

data class VrxUiState(
  val shizukuStatus: ShizukuStatus = ShizukuStatus.NotRunning,
  val games: List<InstalledGame> = emptyList(),
  val featuredGames: List<InstalledGame> = emptyList(),
  val selectedGame: InstalledGame? = null,
  val searchQuery: String = "",
  val filterOnlyGames: Boolean = false,
  val isLoadingGames: Boolean = true,
  val selectedFpsMode: FpsMode = FpsMode.FPS_120,
  val maxHardwareHz: Float = 120f,
  val tweaks: List<OptimizationTweak> = DefaultTweaksProvider.createDefaultTweaks(),
  val boostPhase: BoostPhase = BoostPhase.Prepared(preparedCount = 6),
  val isOverlayActive: Boolean = false,
  val hasOverlayPermission: Boolean = false,
  val statusMessage: String = "",
) {
  val enabledTweaksCount: Int
    get() = tweaks.count { it.isEnabled }
}

object DefaultTweaksProvider {
  fun createDefaultTweaks(enabledIds: Set<String> = defaultRecommendedIds): List<OptimizationTweak> {
    val all =
      listOf(
        OptimizationTweak(
          id = "gpu_clock_lock",
          index = 1,
          title = "Trava de Clock GPU",
          description = "Ativa modo de desempenho fixo e força renderizador SkiaGL de alta frequência.",
          category = TweakCategory.GPU,
        ),
        OptimizationTweak(
          id = "disable_thermal_gos",
          index = 2,
          title = "Desativar Limite Térmico / GOS",
          description = "Suspende throttling térmico via thermalservice e pausa limitador GOS.",
          category = TweakCategory.CPU,
        ),
        OptimizationTweak(
          id = "render_thread_priority",
          index = 3,
          title = "Prioridade Thread de Renderização",
          description = "Ativa SkiaGL Threaded e latch unsignaled para reduzir filas de quadros.",
          category = TweakCategory.GPU,
        ),
        OptimizationTweak(
          id = "frametime_stabilizer",
          index = 4,
          title = "Estabilizador de Frametime",
          description = "Reduz backpressure do SurfaceFlinger para evitar engasgos em tiroteios e lobbies.",
          category = TweakCategory.GPU,
        ),
        OptimizationTweak(
          id = "vulkan_opengl_cache",
          index = 5,
          title = "Limpeza de Cache Vulkan / OpenGL",
          description = "Libera caches antigos e otimiza buffers gráficos antes de iniciar a partida.",
          category = TweakCategory.MEMORIA,
        ),
        OptimizationTweak(
          id = "speed_profile_compile",
          index = 6,
          title = "Compilação Speed-Profile do Jogo",
          description = "Executa cmd package compile -m speed-profile -f no pacote selecionado.",
          category = TweakCategory.CPU,
        ),
        OptimizationTweak(
          id = "touch_latency_reduction",
          index = 7,
          title = "Redução de Latência de Toque",
          description = "Remove bloqueio de toque acidental e eleva resposta de ponteiro.",
          category = TweakCategory.REDE,
        ),
        OptimizationTweak(
          id = "block_bg_sync",
          index = 8,
          title = "Bloqueio de Sincronização em 2º Plano",
          description = "Desativa sincronização automática em background para poupar CPU e rede.",
          category = TweakCategory.SISTEMA,
        ),
        OptimizationTweak(
          id = "ram_trim_boost",
          index = 9,
          title = "Liberação Agressiva de Memória RAM",
          description = "Encerra processos ociosos em segundo plano com am kill-all e trim-caches.",
          category = TweakCategory.MEMORIA,
        ),
        OptimizationTweak(
          id = "game_mode_performance",
          index = 10,
          title = "Forçar Game Mode Performance",
          description = "Define modo performance dedicado e escala 1.0 no GameManager do Android.",
          category = TweakCategory.SISTEMA,
        ),
        OptimizationTweak(
          id = "zero_system_animations",
          index = 11,
          title = "Zerar Animações do Sistema",
          description = "Define escalas de janela, transição e animador para 0.0 durante o jogo.",
          category = TweakCategory.SISTEMA,
        ),
        OptimizationTweak(
          id = "foreground_io_priority",
          index = 12,
          title = "Prioridade I/O & Bucket Ativo",
          description = "Move o jogo para standby-bucket active e adiciona à whitelist do Doze.",
          category = TweakCategory.CPU,
        ),
        OptimizationTweak(
          id = "disable_adaptive_battery",
          index = 13,
          title = "Desativar Economia Adaptativa",
          description = "Impede redução automática de clock pelo Adaptive Power Saver.",
          category = TweakCategory.SISTEMA,
        ),
        OptimizationTweak(
          id = "surfaceflinger_accel",
          index = 14,
          title = "Aceleração SurfaceFlinger & Buffer Age",
          description = "Habilita buffer age do HWUI e otimiza composição de quadros em tela cheia.",
          category = TweakCategory.GPU,
        ),
        OptimizationTweak(
          id = "wifi_low_latency",
          index = 15,
          title = "Modo Wi-Fi Baixa Latência",
          description = "Ativa low-latency mode no controlador Wi-Fi e mantém rádio sempre acordado.",
          category = TweakCategory.REDE,
        ),
      )
    return all.map { it.copy(isEnabled = it.id in enabledIds) }
  }

  val defaultRecommendedIds: Set<String> =
    setOf(
      "gpu_clock_lock",
      "disable_thermal_gos",
      "render_thread_priority",
      "frametime_stabilizer",
      "speed_profile_compile",
      "touch_latency_reduction",
    )
}
