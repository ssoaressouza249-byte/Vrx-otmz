package com.raylan.vrxotmz.shizuku

import android.content.Context
import androidx.annotation.Keep
import com.raylan.vrxotmz.IShellService
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.system.exitProcess

class ShellUserService @Keep constructor() : IShellService.Stub() {

  @Keep
  constructor(@Suppress("UNUSED_PARAMETER") context: Context) : this()

  override fun runCommand(command: String): String {
    return runCatching {
        val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
        val stdout =
          BufferedReader(InputStreamReader(process.inputStream)).use { it.readText().trim() }
        val stderr =
          BufferedReader(InputStreamReader(process.errorStream)).use { it.readText().trim() }
        val exitCode = process.waitFor()
        if (exitCode == 0) {
          if (stdout.isNotEmpty()) stdout else "OK"
        } else {
          "EXIT($exitCode): ${stderr.ifEmpty { stdout }}"
        }
      }
      .getOrElse { error -> "ERR: ${error.message ?: "unknown"}" }
  }

  override fun destroy() {
    runCatching { exitProcess(0) }
  }
}
