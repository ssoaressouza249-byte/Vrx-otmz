package com.raylan.vrxotmz.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.vrxotmz.R

data class IntegrityReport(
  val isValid: Boolean,
  val actualAppName: String,
  val actualPackageName: String,
)

object SecurityGuard {
  const val EXPECTED_APP_NAME = "VRX OTMZ"
  const val EXPECTED_PACKAGE_NAME = "com.raylan.vrxotmz"

  fun verifyIntegrity(context: Context): IntegrityReport {
    val actualPackage = runCatching { context.packageName }.getOrDefault("")
    val stringAppName = runCatching { context.getString(R.string.app_name) }.getOrDefault("")
    val labelAppName =
      runCatching {
          val pm = context.packageManager
          val appInfo = pm.getApplicationInfo(actualPackage, 0)
          pm.getApplicationLabel(appInfo).toString()
        }
        .getOrDefault(stringAppName)

    val appNameMatches =
      stringAppName == EXPECTED_APP_NAME && labelAppName == EXPECTED_APP_NAME
    val packageMatches = actualPackage == EXPECTED_PACKAGE_NAME

    return IntegrityReport(
      isValid = appNameMatches && packageMatches,
      actualAppName = labelAppName.ifEmpty { stringAppName },
      actualPackageName = actualPackage,
    )
  }

  fun launchUninstall(context: Context) {
    runCatching {
      val intent =
        Intent(Intent.ACTION_DELETE, Uri.parse("package:${context.packageName}")).apply {
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(intent)
    }
  }
}

@Composable
fun SecurityBreachScreen(report: IntegrityReport) {
  val context = LocalContext.current

  BackHandler(enabled = true) {}

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors = listOf(Color(0xFF7F0000), Color(0xFFB71C1C), Color(0xFF4A0000))
          )
        )
        .systemBarsPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier.widthIn(max = 520.dp)
          .fillMaxWidth()
          .background(Color(0x55000000), RoundedCornerShape(20.dp))
          .border(2.dp, Color(0xFFFF8A80), RoundedCornerShape(20.dp))
          .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = "Alerta de integridade violada",
        tint = Color.White,
        modifier = Modifier.size(64.dp),
      )

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "PROTEÇÃO DE INTEGRIDADE ATIVADA",
        style = MaterialTheme.typography.headlineSmall,
        color = Color.White,
        fontWeight = FontWeight.ExtraBold,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text =
          "O nome original (${SecurityGuard.EXPECTED_APP_NAME}) ou o pacote oficial (${SecurityGuard.EXPECTED_PACKAGE_NAME}) foi modificado. A execução foi bloqueada permanentemente.",
        style = MaterialTheme.typography.bodyLarge,
        color = Color(0xFFFFEBEE),
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(16.dp))

      Column(
        modifier =
          Modifier.fillMaxWidth()
            .background(Color(0x66000000), RoundedCornerShape(12.dp))
            .padding(12.dp)
      ) {
        Text(
          text = "NOME DETECTADO: ${report.actualAppName.ifEmpty { "DESCONHECIDO" }}",
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = Color(0xFFFFCDD2),
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "PACOTE DETECTADO: ${report.actualPackageName.ifEmpty { "DESCONHECIDO" }}",
          fontFamily = FontFamily.Monospace,
          fontSize = 12.sp,
          color = Color(0xFFFFCDD2),
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      Button(
        onClick = { SecurityGuard.launchUninstall(context) },
        modifier =
          Modifier.fillMaxWidth()
            .height(56.dp)
            .testTag("uninstall_now_button"),
        shape = RoundedCornerShape(14.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = Color(0xFFB71C1C),
          ),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = "Desinstalar agora",
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.size(8.dp))
        Text(
          text = "DESINSTALAR AGORA",
          fontWeight = FontWeight.ExtraBold,
          fontSize = 15.sp,
          letterSpacing = 1.sp,
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "VRX OTMZ • Desenvolvido por Raylan",
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        color = Color(0xFFFFCDD2),
      )
    }
  }
}
