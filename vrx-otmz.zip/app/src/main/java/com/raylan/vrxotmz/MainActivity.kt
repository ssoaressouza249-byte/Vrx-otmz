package com.raylan.vrxotmz

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.vrxotmz.security.SecurityBreachScreen
import com.raylan.vrxotmz.security.SecurityGuard
import com.raylan.vrxotmz.shizuku.ShizukuEngine
import com.raylan.vrxotmz.ui.screens.VrxHomeScreen
import com.raylan.vrxotmz.ui.theme.VrxOtmzTheme
import com.raylan.vrxotmz.viewmodel.VrxViewModel
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

  private val viewModel: VrxViewModel by viewModels()

  private val shizukuPermissionListener =
    Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
      if (requestCode == ShizukuEngine.SHIZUKU_PERMISSION_REQUEST_CODE) {
        viewModel.onShizukuPermissionResult()
      }
    }

  private val shizukuBinderReceivedListener =
    Shizuku.OnBinderReceivedListener { viewModel.refreshShizukuStatus() }

  private val shizukuBinderDeadListener =
    Shizuku.OnBinderDeadListener { viewModel.refreshShizukuStatus() }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    runCatching {
      Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
      Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener)
      Shizuku.addBinderDeadListener(shizukuBinderDeadListener)
    }

    val integrityReport = SecurityGuard.verifyIntegrity(this)

    setContent {
      VrxOtmzTheme {
        if (!integrityReport.isValid) {
          SecurityBreachScreen(report = integrityReport)
        } else {
          val uiState by viewModel.uiState.collectAsStateWithLifecycle()

          val notificationPermissionLauncher =
            rememberLauncherForActivityResult(
              contract = ActivityResultContracts.RequestPermission()
            ) {
              viewModel.toggleFloatingOverlay()
            }

          // Detecção automática do Shizuku ao abrir o aplicativo
          LaunchedEffect(Unit) {
            runCatching {
              if (
                Shizuku.pingBinder() &&
                  Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
              ) {
                Shizuku.requestPermission(ShizukuEngine.SHIZUKU_PERMISSION_REQUEST_CODE)
              }
              viewModel.refreshShizukuStatus()
            }
          }

          VrxHomeScreen(
            uiState = uiState,
            onShizukuClick = { viewModel.openShizukuAppOrCheck() },
            onSelectGame = { game -> viewModel.selectGame(game) },
            onSearchQueryChange = { query -> viewModel.updateSearchQuery(query) },
            onToggleFilterOnlyGames = { viewModel.toggleFilterOnlyGames() },
            onSelectFpsMode = { mode -> viewModel.selectFpsMode(mode) },
            onToggleTweak = { tweakId -> viewModel.toggleTweak(tweakId) },
            onSetAllTweaks = { enabled -> viewModel.setAllTweaks(enabled) },
            onTurbinaBoostClick = { viewModel.executeTurbinaBoost() },
            onLaunchGame = { viewModel.launchSelectedGame() },
            onRestoreDefaults = { viewModel.restoreSystemDefaults() },
            onToggleOverlay = {
              if (
                !uiState.isOverlayActive &&
                  uiState.hasOverlayPermission &&
                  Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                  ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS,
                  ) != PackageManager.PERMISSION_GRANTED
              ) {
                runCatching {
                  notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }.onFailure {
                  viewModel.toggleFloatingOverlay()
                }
              } else {
                viewModel.toggleFloatingOverlay()
              }
            },
          )
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    viewModel.refreshShizukuStatus()
    viewModel.refreshOverlayPermission()
  }

  override fun onDestroy() {
    super.onDestroy()
    runCatching {
      Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
      Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener)
      Shizuku.removeBinderDeadListener(shizukuBinderDeadListener)
    }
  }
}
