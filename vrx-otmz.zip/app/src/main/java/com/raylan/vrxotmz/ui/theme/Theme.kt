package com.raylan.vrxotmz.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val VrxDarkColorScheme =
  darkColorScheme(
    primary = NeonCyan,
    onPrimary = VrxBackground,
    primaryContainer = VrxSurfaceElevated,
    onPrimaryContainer = NeonCyan,
    secondary = NeonGreen,
    onSecondary = VrxBackground,
    secondaryContainer = VrxSurfaceElevated,
    onSecondaryContainer = NeonGreen,
    tertiary = NeonCyanMuted,
    onTertiary = VrxTextPrimary,
    background = VrxBackground,
    onBackground = VrxTextPrimary,
    surface = VrxSurface,
    onSurface = VrxTextPrimary,
    surfaceVariant = VrxSurfaceElevated,
    onSurfaceVariant = VrxTextSecondary,
    outline = VrxSurfaceBorder,
    error = VrxDanger,
    onError = VrxTextPrimary,
  )

private val VrxShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
  )

@Composable
fun VrxOtmzTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = VrxDarkColorScheme,
    typography = Typography,
    shapes = VrxShapes,
    content = content,
  )
}
