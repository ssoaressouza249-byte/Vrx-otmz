package com.raylan.vrxotmz.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.vrxotmz.data.GameRepository
import com.raylan.vrxotmz.model.BoostPhase
import com.raylan.vrxotmz.model.DefaultTweaksProvider
import com.raylan.vrxotmz.model.FpsMode
import com.raylan.vrxotmz.model.InstalledGame
import com.raylan.vrxotmz.model.ShizukuStatus
import com.raylan.vrxotmz.model.VrxUiState
import com.raylan.vrxotmz.overlay.FloatingOverlayService
import com.raylan.vrxotmz.shizuku.ShizukuEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class VrxViewModel(application: Application) : AndroidViewModel(application) {

  private val repository = GameRepository(application)
  private val shizukuEngine = ShizukuEngine(application)

  private val _uiState = MutableStateFlow(VrxUiState())
  val uiState: StateFlow<VrxUiState> = _uiState.asStateFlow()

  init {
    val snapshot = repository.loadPreparedProfile()
    val restoredTweaks = DefaultTweaksProvider.createDefaultTweaks(snapshot.enabledTweakIds)
    val maxHz = shizukuEngine.detectMaxHardwareRefreshRate()
    val preparedCount = restoredTweaks.count { it.isEnabled }

    _uiState.update {
      it.copy(
        selectedFpsMode = snapshot.fpsMode,
        maxHardwareHz = maxHz,
        tweaks = restoredTweaks,
        boostPhase = BoostPhase.Prepared(preparedCount),
        hasOverlayPermission = checkOverlayPermission(),
        isOverlayActive = FloatingOverlayService.isOverlayRunning.value,
      )
    }

    observeOverlayState()
    refreshShizukuStatus()
    loadGames(savedPackage = snapshot.packageName)
  }

  private fun observeOverlayState() {
    viewModelScope.launch {
      FloatingOverlayService.isOverlayRunning.collect { running ->
        _uiState.update {
          it.copy(
            isOverlayActive = running,
            hasOverlayPermission = checkOverlayPermission(),
          )
        }
      }
    }
  }

  fun refreshShizukuStatus() {
    val status = shizukuEngine.getStatus()
    _uiState.update { it.copy(shizukuStatus = status) }
  }

  fun requestShizukuPermissionOnLaunch() {
    refreshShizukuStatus()
    shizukuEngine.requestPermissionIfNeeded()
  }

  fun onShizukuPermissionResult() {
    refreshShizukuStatus()
  }

  fun openShizukuAppOrCheck() {
    refreshShizukuStatus()
    val current = _uiState.value.shizukuStatus
    when (current) {
      ShizukuStatus.PermissionRequired -> {
        shizukuEngine.requestPermissionIfNeeded()
      }
      ShizukuStatus.NotRunning -> {
        val ctx = getApplication<Application>()
        val launched =
          runCatching {
              val intent = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
              if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                true
              } else {
                false
              }
            }
            .getOrDefault(false)
        _uiState.update {
          it.copy(
            statusMessage =
              if (launched) "Abrindo app Shizuku para ativação do serviço..."
              else "Instale e inicie o app Shizuku para habilitar otimizações privilegiadas."
          )
        }
      }
      is ShizukuStatus.Authorized -> {
        _uiState.update {
          it.copy(statusMessage = "Shizuku conectado e autorizado (UID ${current.uid}).")
        }
      }
    }
  }

  fun loadGames(savedPackage: String? = _uiState.value.selectedGame?.packageName) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoadingGames = true) }
      val (featured, allGames) = repository.loadInstalledGames()

      val preferred =
        allGames.firstOrNull { it.packageName == savedPackage }
          ?: featured.firstOrNull { it.isInstalled }
          ?: allGames.firstOrNull { it.isGameCategory }
          ?: allGames.firstOrNull()

      _uiState.update { state ->
        state.copy(
          featuredGames = featured,
          games = allGames,
          selectedGame = preferred,
          isLoadingGames = false,
        )
      }
      persistPreparedProfile()
    }
  }

  fun updateSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun toggleFilterOnlyGames() {
    _uiState.update { it.copy(filterOnlyGames = !it.filterOnlyGames) }
  }

  fun selectGame(game: InstalledGame) {
    if (!game.isInstalled) {
      _uiState.update {
        it.copy(statusMessage = "${game.appName} (${game.packageName}) não está instalado neste dispositivo.")
      }
      return
    }
    _uiState.update { state ->
      val preparedCount = state.tweaks.count { it.isEnabled }
      state.copy(
        selectedGame = game,
        boostPhase = BoostPhase.Prepared(preparedCount),
        statusMessage = "",
      )
    }
    persistPreparedProfile()
  }

  // Only prepares UI state — NEVER executes Shizuku commands until TURBINA BOOST is pressed
  fun selectFpsMode(mode: FpsMode) {
    _uiState.update { state ->
      val preparedCount = state.tweaks.count { it.isEnabled }
      state.copy(
        selectedFpsMode = mode,
        boostPhase = BoostPhase.Prepared(preparedCount),
        statusMessage = "",
      )
    }
    persistPreparedProfile()
  }

  // Only prepares UI state — NEVER executes Shizuku commands until TURBINA BOOST is pressed
  fun toggleTweak(tweakId: String) {
    _uiState.update { state ->
      val updated =
        state.tweaks.map { tweak ->
          if (tweak.id == tweakId) tweak.copy(isEnabled = !tweak.isEnabled) else tweak
        }
      val count = updated.count { it.isEnabled }
      state.copy(
        tweaks = updated,
        boostPhase = BoostPhase.Prepared(count),
        statusMessage = "",
      )
    }
    persistPreparedProfile()
  }

  fun setAllTweaks(enabled: Boolean) {
    _uiState.update { state ->
      val updated = state.tweaks.map { it.copy(isEnabled = enabled) }
      val count = updated.count { it.isEnabled }
      state.copy(
        tweaks = updated,
        boostPhase = BoostPhase.Prepared(count),
        statusMessage = "",
      )
    }
    persistPreparedProfile()
  }

  fun executeTurbinaBoost() {
    val state = _uiState.value
    if (state.boostPhase is BoostPhase.Applying) return

    val targetGame = state.selectedGame
    if (targetGame == null || !targetGame.isInstalled) {
      _uiState.update {
        it.copy(
          boostPhase = BoostPhase.Error("Selecione um jogo instalado antes de ativar a Turbina Boost.")
        )
      }
      return
    }

    refreshShizukuStatus()
    if (_uiState.value.shizukuStatus is ShizukuStatus.PermissionRequired) {
      shizukuEngine.requestPermissionIfNeeded()
      _uiState.update {
        it.copy(
          boostPhase =
            BoostPhase.Error("Autorize o Shizuku na janela do sistema e toque novamente em TURBINA BOOST.")
        )
      }
      return
    }

    val enabledTweaks = state.tweaks.filter { it.isEnabled }
    val totalSteps = enabledTweaks.size + 1

    viewModelScope.launch {
      _uiState.update {
        it.copy(
          boostPhase = BoostPhase.Applying(1, totalSteps, "Inicializando ${state.selectedFpsMode.title}..."),
          statusMessage = "",
        )
      }

      val result =
        shizukuEngine.applyTurbinaBoost(
          packageName = targetGame.packageName,
          fpsMode = state.selectedFpsMode,
          enabledTweaks = enabledTweaks,
          onProgress = { step, total, label ->
            _uiState.update {
              it.copy(boostPhase = BoostPhase.Applying(step, total, label))
            }
          },
        )

      if (result.success) {
        _uiState.update {
          it.copy(
            maxHardwareHz = result.maxHardwareHz,
            boostPhase =
              BoostPhase.Active(
                gameName = targetGame.appName,
                fpsMode = state.selectedFpsMode,
                appliedCount = result.appliedCount,
                maxHardwareHz = result.maxHardwareHz,
                summaryLog = result.logs,
              ),
          )
        }
      } else {
        _uiState.update {
          it.copy(
            boostPhase = BoostPhase.Error(result.errorMessage ?: "Falha ao aplicar Turbina Boost.")
          )
        }
      }
    }
  }

  fun restoreSystemDefaults() {
    val pkg = _uiState.value.selectedGame?.packageName
    viewModelScope.launch {
      val result = shizukuEngine.restoreDefaults(pkg)
      _uiState.update { state ->
        val count = state.tweaks.count { it.isEnabled }
        if (result.success) {
          state.copy(
            boostPhase = BoostPhase.Prepared(count),
            statusMessage = "Configurações originais do sistema restauradas com sucesso.",
          )
        } else {
          state.copy(
            statusMessage = result.errorMessage ?: "Não foi possível restaurar sem Shizuku ativo."
          )
        }
      }
    }
  }

  fun launchSelectedGame() {
    val pkg = _uiState.value.selectedGame?.packageName ?: return
    val ok = repository.launchGame(pkg)
    if (!ok) {
      _uiState.update { it.copy(statusMessage = "Não foi possível abrir o jogo selecionado.") }
    }
  }

  fun checkOverlayPermission(): Boolean {
    return runCatching { Settings.canDrawOverlays(getApplication()) }.getOrDefault(false)
  }

  fun refreshOverlayPermission() {
    _uiState.update {
      it.copy(
        hasOverlayPermission = checkOverlayPermission(),
        isOverlayActive = FloatingOverlayService.isOverlayRunning.value,
      )
    }
  }

  fun requestOverlayPermission() {
    val ctx = getApplication<Application>()
    runCatching {
      val intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${ctx.packageName}"),
          )
          .apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
      ctx.startActivity(intent)
    }
  }

  fun toggleFloatingOverlay() {
    val ctx = getApplication<Application>()
    if (!checkOverlayPermission()) {
      requestOverlayPermission()
      return
    }
    if (FloatingOverlayService.isOverlayRunning.value) {
      runCatching { ctx.stopService(Intent(ctx, FloatingOverlayService::class.java)) }
      _uiState.update { it.copy(isOverlayActive = false) }
    } else {
      persistPreparedProfile()
      runCatching {
        val intent = Intent(ctx, FloatingOverlayService::class.java)
        ctx.startForegroundService(intent)
      }
      _uiState.update { it.copy(isOverlayActive = true) }
    }
  }

  fun clearStatusMessage() {
    _uiState.update { it.copy(statusMessage = "") }
  }

  private fun persistPreparedProfile() {
    val state = _uiState.value
    repository.savePreparedProfile(
      packageName = state.selectedGame?.packageName,
      gameName = state.selectedGame?.appName,
      fpsMode = state.selectedFpsMode,
      enabledTweakIds = state.tweaks.filter { it.isEnabled }.map { it.id }.toSet(),
    )
  }

  override fun onCleared() {
    super.onCleared()
    shizukuEngine.unbindUserService()
  }
}
